﻿
namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string connectionString = 
            @"Server=DELL3330\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=True";
    }
}
